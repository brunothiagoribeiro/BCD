package prjExercicio05;

public class ContaBancaria {
	private int numero;
	private String titular;
	 double saldo;
	
	//Construtor s/ parametros
	public ContaBancaria() {
        
    }
	//Construtor c/ parametros
	public ContaBancaria(int numero , String titular, double saldo) {
		this.numero = numero;
        this.titular = titular;
        this.saldo = saldo;
        

	}
	
	//Methodos
	public void depositar(double valor) {
		
	}
	public void sacar(double valor) {
		
	}
	
	//Getters e setters
	//Getters e Setters
			public int getnumero() { 
		         return numero; 
		    } 
			public void setnumero(int numero) {
		          this.numero = numero;
		    } 
			public String getTitular() {
				return titular;
			}
			public void setTitular(String titular) {
		          this.titular = titular;
			
			}
			public double getsaldo() { 
		         return saldo; 
			}
			public void setsaldo(double saldo) {
		          this.saldo = saldo;
			
			}
			
			

}


