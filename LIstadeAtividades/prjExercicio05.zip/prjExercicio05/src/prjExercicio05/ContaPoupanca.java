package prjExercicio05;

public class ContaPoupanca extends ContaBancaria {
//Atributos
	double taxaJuros;
	
	public void calcularJuros(int tempo) {
		saldo *=(1 + taxaJuros * tempo);
	} 
}
