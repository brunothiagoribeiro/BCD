package prjExercicio01;

public class Carro {
	String marca;
	String nomeCarro;
	String modelo;
	int anoFabricacao;
	
	//Construtor s/ parametros
	public Carro() {
        
    }
	//Construtor c/ parametros
	public Carro(String marca , String nomeCarro, String modelo, int anoFabricacao) {
		this.marca = marca;
        this.nomeCarro = nomeCarro;
        this.modelo = modelo;
        this.anoFabricacao = anoFabricacao;
        
             
	}
	
	// Methodo exibirInfo
	public  void exibirInfo(){
		System.out.println("A marca do carro é : " + this.marca);
		System.out.println("O modelo do carro é : " + this.modelo);
		System.out.println("O ano de fabricação do carro é : " + this.anoFabricacao);
		System.out.println("O nome do carro é  :" + this.nomeCarro);
	}
}
