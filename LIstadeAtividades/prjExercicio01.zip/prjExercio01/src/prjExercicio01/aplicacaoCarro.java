package prjExercicio01;

public class aplicacaoCarro {

	public static void main(String[] args) {
		
		
		Carro ranger = new Carro ("ford", "ranger", "2007" , 01);
	    Carro uno = new Carro ("fiat", "uno", "2020", 02);

	    ranger.exibirInfo();
	    uno.exibirInfo();
		

	}
    
}

