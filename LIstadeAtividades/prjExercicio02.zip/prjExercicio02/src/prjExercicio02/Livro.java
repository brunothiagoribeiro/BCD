package prjExercicio02;

public class Livro {
	String titulo;
	String autor;
	int numPages;
	double preco;
	
	//Construtor s/ parametros
		public Livro() {
	        
	    }
		//Construtor c/ parametros
		public Livro(String titulo , String autor, int numPages, double preco) {
			this.titulo = titulo;
	        this.autor = autor;
	        this.numPages = numPages;
	        this.preco = preco;

		}
		
		//Getters e Setters
		public String getTitulo() { 
	         return titulo; 
	    } 
		public void setTitulo(String titulo) {
	          this.titulo = titulo;
	    } 
		public String getAutor() {
			return autor;
		}
		public void setAutor(String autor) {
	          this.autor = autor;
		
		}
		public int getnumPages() { 
	         return numPages; 
		}
		public void setnumPages(int numPages) {
	          this.numPages = numPages;
		
		}
		public double getpreco() { 
	         return preco;
		}
		public void setpreco(double preco) {
	          this.preco = preco;
		

		}
		//Methodos
		public void aplicarDesconto() {
			this.preco = preco - 15;
		}
		public  void exibirInfo(){
			System.out.println("O titulo do livro é : " + this.titulo);
			System.out.println("O autor é : " + this.autor);
			System.out.println("Quantidade de paginas : " + this.numPages);
			System.out.println("O seu preço é  :" + this.preco);
		}
}

