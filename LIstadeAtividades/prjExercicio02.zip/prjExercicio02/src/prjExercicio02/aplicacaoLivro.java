package prjExercicio02;



public class aplicacaoLivro {

	public static void main(String[] args) {
		Livro alice_no_pais_das_maravilhas = new Livro ("Alice no pais dasmaravilhas ", "Vedilsinho", 145 , 200);
	    Livro cinquenta_tons_de_cinzas = new Livro ("50 tons de cinzas", "Leandrinho", 202, 800);
	    alice_no_pais_das_maravilhas.exibirInfo();
	    cinquenta_tons_de_cinzas.exibirInfo();
	    alice_no_pais_das_maravilhas.aplicarDesconto();
	    cinquenta_tons_de_cinzas.aplicarDesconto();
	    alice_no_pais_das_maravilhas.exibirInfo();
	    cinquenta_tons_de_cinzas.exibirInfo();

	}

}
