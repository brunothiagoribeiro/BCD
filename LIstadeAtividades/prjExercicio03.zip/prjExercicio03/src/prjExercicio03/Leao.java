package prjExercicio03;

	public class Leao extends Animal {
		
		public void nadar() {
			System.out.println("O leão esta caçando");
		}
		
	

	}
