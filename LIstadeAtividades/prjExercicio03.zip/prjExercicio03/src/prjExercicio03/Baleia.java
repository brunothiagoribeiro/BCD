package prjExercicio03;

	public class Baleia extends Animal {
		
		public void nadar() {
			System.out.println("A baleia esta nadando");
		}
		
	

	}



