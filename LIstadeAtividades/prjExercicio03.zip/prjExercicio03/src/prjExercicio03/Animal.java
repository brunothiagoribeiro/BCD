package prjExercicio03;

public class Animal {
	String nome;
	int idade;
	String raca;
	//Construtor s/ parametros
	public Animal() {
        
    }
	//Construtor c/ parametros
	public Animal(String nome ,int idade,String raca) {
		this.nome = nome;
        this.idade = idade;
        this.raca = raca;
	}
	public void fazerSom() {
		System.out.println("Seu animal ira fazer um som");
	}
}
