package prjExercicio4;

public class Veiculo {
	
	String marca;
	String modelo;
	int velocidade;
	
	
	//Construtor s/ parametros
			public Veiculo() {
		        
		    }
			//Construtor c/ parametros
			public Veiculo(String marca , String modelo, int velocidade) {
				this.marca = marca;
		        this.modelo = modelo;
		        this.velocidade = velocidade;
		        

			}
			
			//Methodos
			public void Acelerar() {
				this.velocidade = velocidade + 10;
				System.out.println("O veiculo está acelerando");
			}
			public void Frear() {
				this.velocidade = velocidade - 10;
				System.out.println("O veiculo está freando");
		}
}
