package prjExercicio4;

public class Caminhao {
	public void acelerar() {
		System.out.println("O caminhao está acelerando");
	}
	public void frear() {
		System.out.println("O caminhao esta freando");
	}

}
