package prjExercicio4;

public class Moto {
	public void acelerar() {
		System.out.println("A moto está acelerando");
	}
	public void frear() {
		System.out.println("A moto esta freando");
	}

}
