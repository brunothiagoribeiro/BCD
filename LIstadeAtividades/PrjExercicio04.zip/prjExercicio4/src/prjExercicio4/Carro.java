package prjExercicio4;

public class Carro {
	public void acelerar() {
		System.out.println("O carro está acelerando");
	}
	public void frear() {
		System.out.println("O carro esta freando");
	}

}
